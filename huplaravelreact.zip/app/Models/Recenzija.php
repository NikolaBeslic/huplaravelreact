<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Recenzija extends Model
{
    //
    protected $table = 'recenzija';
    protected $primaryKey = 'recenzijaid';
}

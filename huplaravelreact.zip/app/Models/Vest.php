<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vest extends Model
{
    //
    protected $table = 'vest';
    protected $primaryKey = 'vestid';
}

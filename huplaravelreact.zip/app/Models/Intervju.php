<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Intervju extends Model
{
    //

    protected $table = 'intervju';
    protected $primaryKey = 'intervjuid';
}
